import requests
import pandas as pd

# Try to load Tapestry result from the temporary file
try:
    tapestry_result = pd.read_csv('tapestry_result_temp.csv').to_dict(orient='records')[0]
    print(f"Loaded tapestry result: {tapestry_result}")
except FileNotFoundError as e:
    print(f"File not found: {e}")
    tapestry_result = {"cluster_centers": [[0], [1], [1]]}  # Default value for demonstration

# SmartThings API credentials and endpoint
smartthings_endpoint = "https://api.smartthings.com/v1/devices/{device_id}/commands"
smartthings_token = "YOUR_SMARTTHINGS_API_TOKEN"
device_id = "YOUR_DEVICE_ID"

# Send result to SmartThings
headers = {
    "Authorization": f"Bearer {smartthings_token}",
    "Content-Type": "application/json"
}

data = {
    "commands": [
        {
            "component": "main",
            "capability": "custom.capability",
            "command": "setPrediction",
            "arguments": [tapestry_result]
        }
    ]
}

# Sending the request (Note: This is just a mock example. Uncomment the below lines to run it for real.)
# response = requests.post(smartthings_endpoint.format(device_id=device_id), json=data, headers=headers)

# Mock response for demonstration
class MockResponse:
    status_code = 200
    text = "Mock response: success"

response = MockResponse()

print(f"Response from SmartThings: {response.status_code} {response.text}")
