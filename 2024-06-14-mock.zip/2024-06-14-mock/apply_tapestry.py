import pandas as pd
from sklearn.cluster import KMeans
import os

def tapestry_algorithm(data, n_clusters=3):
    """
    Apply Tapestry algorithm to the data.
    
    Parameters:
        data (pd.Series or np.array): The input data for clustering.
        n_clusters (int): The number of clusters to form.
        
    Returns:
        dict: A dictionary containing the cluster centers.
    """
    # Ensure the data is in the correct format
    if isinstance(data, pd.Series):
        data = data.values.reshape(-1, 1)
    elif isinstance(data, pd.DataFrame):
        data = data.values
    
    # Apply K-means clustering
    kmeans = KMeans(n_clusters=n_clusters)
    kmeans.fit(data)
    
    # Get the cluster centers
    cluster_centers = kmeans.cluster_centers_
    
    return {"cluster_centers": cluster_centers.tolist()}

# 임시값을 직접 넣기
data = pd.DataFrame({'predicted_fault': [0, 1, 0, 1, 0]})

# Apply Tapestry algorithm
tapestry_result = tapestry_algorithm(data['predicted_fault'])

# Print Tapestry result instead of saving to file
print(f"Tapestry result: {tapestry_result}")

# 임시로 결과를 CSV로 저장
tapestry_result_path = 'tapestry_result_temp.csv'
try:
    os.makedirs('predictions', exist_ok=True)
    pd.DataFrame([tapestry_result]).to_csv(tapestry_result_path, index=False)
    print(f"Tapestry result saved to {tapestry_result_path}")
except Exception as e:
    print(f"Error saving tapestry result: {e}")
